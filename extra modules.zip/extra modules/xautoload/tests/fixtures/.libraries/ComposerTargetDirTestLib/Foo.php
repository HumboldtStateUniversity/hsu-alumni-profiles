<?php

namespace Acme\ComposerTargetDirTestLib;


class Foo {

} 
