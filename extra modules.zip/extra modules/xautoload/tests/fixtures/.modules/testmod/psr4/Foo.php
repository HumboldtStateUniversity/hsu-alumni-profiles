<?php

namespace Drupal\testmod;

class Foo {}
