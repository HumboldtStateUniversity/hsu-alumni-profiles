---
name: 📚 Documentation
about: Report an issue related to documentation.
labels: "documentation"
---

## 📚 Documentation

(A clear and concise description of what the issue is.)

### Have you read the [Code of Conduct](https://github.com/SoftCreatR/JSONPath/blob/main/CODE_OF_CONDUCT.md)?

[ ] I have read the Code of Conduct
